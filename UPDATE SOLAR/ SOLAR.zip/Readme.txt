# 
Alessandro Awani 

38863316

Solar System Simulation

This program simulates a basic model of our solar system, including the sun, planets, moons, and other celestial bodies.

Compilation

Right-click and open in terminal in the directory 

To compile the program, use the following command in the terminal:


javac *.java

Execution
After compilation, you can run the simulation using the following command:

java SolarSystemSim


Controls
Use the sliders to adjust the time multiplier and zoom factor.
Check or uncheck the "Show Labels" and "Show Info" checkboxes to toggle labels and information display.